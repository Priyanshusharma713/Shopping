const cartReducer = () => {
  return [];
};

export default cartReducer;

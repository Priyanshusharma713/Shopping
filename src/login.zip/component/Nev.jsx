const Nev = () => {
  return (
    <>
      <footer className="footer-container">
            <div className="footer-content">
                <div className="footer-section">
                    <h3>About Us</h3>
                    <p>We are a leading clothing brand offering the latest fashion trends.</p>
                </div>
                <div className="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="/shop">Shop</a></li>
                        <li><a href="/about">About Us</a></li>
                        <li><a href="/contact">Contact</a></li>
                        <li><a href="/faq">FAQ</a></li>
                    </ul>
                </div>
                <div className="footer-section">
                    <h3>Contact Us</h3>
                    <p>Email: priyanshubca2021@gmail.com</p>
                    <p>Phone: +91 7982968404</p>
                </div>
                <div className="footer-section social-media">
                    <h3>Follow Us</h3>
                    <a href="www.facebook.com"><i className="fab fa-facebook-f"></i>Facebook</a>
                    <a href="www.twitter.com"><i className="fab fa-twitter">Twitter</i></a>
                    <a href="https://www.instagram.com/priyanshusharma713/"><i className="fab fa-instagram"></i>Instagram</a>
                </div>
            </div>
            <div className="footer-bottom">
                <p>&copy; 2024 Clothing Brand. All rights reserved.</p>
            </div>
        </footer>
    </>
  );
};
export default Nev;

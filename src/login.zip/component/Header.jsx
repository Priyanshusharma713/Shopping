import Layout from "../Routing/Layout";
import img1 from "../images/logosala.png";

const Header = () => {
  return (
    <>
      <header className="header">
        <div className="logo">
          <img src={img1} alt="Logo" />
        </div>
        <nav className="nav">
          <ul>
            <li>
              <Layout />
            </li>
          </ul>
        </nav>
      </header>
    </>
  );
};
export default Header;

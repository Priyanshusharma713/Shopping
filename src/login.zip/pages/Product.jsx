import Header from "../component/Header";
import Nev from "../component/Nev";
import img1 from "../images/cloths2.jpg"

const Product = () => {
  return (
    <>
      <Header/>
      <div className="home">
      <div className="product-container">
            <div className="product-image">
                <img src={img1} alt="Product" />
            </div>
            <div className="product-details">
                <h1 className="product-title">Amazing Product</h1>
                <p className="product-description">
                    This is a fantastic product that will help you with your daily needs. It's made from high-quality materials and designed to last.
                </p>
                <span className="product-price">$49.99</span>
                <button className="add-to-cart">Add to Cart</button>
            </div>
        </div>
      </div>
      <Nev/>
    </>
  );
};
export default Product;

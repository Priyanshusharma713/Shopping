import Header from "../component/Header";
import Nev from "../component/Nev";
import img1 from "../images/logosala.png";

const Login = () => {

    const loginHandle =(e) => {
        e.preventDefault()
        window.localStorage.setItem('userType', 'user')
        window.localStorage.setItem('token', 'token')

        window.location.href = "/Home"
    }
    return(
        <>
        <Header/>
        <div className="home">
        {/* .......... */}
            <h1>Login</h1>
        <div className="login-container">
        <div className="logo">
          <img src={img1} alt="Logo" />
        </div>
            <form className="login-form" onSubmit={(e) => loginHandle(e)}>
                <label htmlFor="email">Email:</label>
                <input type="email" id="email" name="email"/>

                <label htmlFor="password">Password:</label>
                <input type="password" id="password" name="password"/>

                <button type="submit">Login</button>
                <p className="forgot-password">
                    <a href="/forgot-password">Forgot Password?</a>
                </p>
            </form>
        </div>
        {/* ........ */}
        </div>  
        <Nev/>
        </>
    );
};
export default Login;
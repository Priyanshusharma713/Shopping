const Singup = () => {
  return (
    <>
      <h1>singup</h1>
    </>
  );
};
export default Singup;
